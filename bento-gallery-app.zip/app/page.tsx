import InteractiveImageBentoGallery from "@/components/ui/bento-gallery"

// Sample data for the image gallery
const imageItems = [
  {
    id: 1,
    title: "Mountain Vista",
    desc: "Serenity above the clouds.",
    url: "https://images.unsplash.com/photo-1486870591958-9b9d0d1dda99?w=800&q=80",
    span: "md:col-span-2 md:row-span-2",
  },
  {
    id: 2,
    title: "Coastal Arch",
    desc: "Where the land meets the sea.",
    url: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&q=80",
    span: "md:row-span-1",
  },
  {
    id: 3,
    title: "Forest Canopy",
    desc: "Sunlight filtering through leaves.",
    url: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800&q=80",
    span: "md:row-span-1",
  },
  {
    id: 4,
    title: "Desert Dunes",
    desc: "Golden sands under the sun.",
    url: "https://images.unsplash.com/photo-1473580044384-7ba9967e16a0?w=800&q=80",
    span: "md:row-span-2",
  },
  {
    id: 5,
    title: "City at Night",
    desc: "A vibrant urban landscape.",
    url: "https://images.unsplash.com/photo-1506606401543-2e73709cebb4?w=800&q=80",
    span: "md:row-span-1",
  },
  {
    id: 6,
    title: "Misty Lake",
    desc: "Morning fog over calm waters.",
    url: "https://images.unsplash.com/photo-1634023233766-0c16b151bfb0?w=800&q=80",
    span: "md:col-span-2 md:row-span-1",
  },
  {
    id: 7,
    title: "Balade Tropicale",
    desc: "Un moment magique sur la plage au coucher du soleil.",
    url: "/baladetropicale.png",
    span: "md:col-span-2 md:row-span-2",
  },
]

export default function Home() {
  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="flex flex-col items-center justify-center py-20 px-4 text-center bg-gradient-to-b from-background to-muted/30">
        <h1 className="text-5xl md:text-6xl font-bold tracking-tight text-foreground mb-4">
          Bento Gallery
        </h1>
        <p className="text-lg md:text-xl text-muted-foreground max-w-2xl">
          A stunning interactive image gallery built with Next.js, shadcn/ui, and Framer Motion.
          Drag to explore, click to expand.
        </p>
        <div className="mt-8 flex gap-4 text-sm text-muted-foreground">
          <span className="px-3 py-1 rounded-full bg-secondary">Next.js 15</span>
          <span className="px-3 py-1 rounded-full bg-secondary">TypeScript</span>
          <span className="px-3 py-1 rounded-full bg-secondary">Tailwind CSS</span>
          <span className="px-3 py-1 rounded-full bg-secondary">Framer Motion</span>
        </div>
      </section>

      {/* Gallery Component */}
      <InteractiveImageBentoGallery
        imageItems={imageItems}
        title="Curated Moments"
        description="A collection of stunning landscapes. Drag to explore, click to expand."
      />

      {/* Footer */}
      <footer className="py-12 text-center text-sm text-muted-foreground border-t">
        <p>Built with Next.js + shadcn/ui + Framer Motion</p>
      </footer>
    </main>
  )
}
